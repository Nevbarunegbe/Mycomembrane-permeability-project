#Python Packages & Statistics
import pandas as pd
import numpy as np
import math
from itertools import compress

#Plotting
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import seaborn as sns

#RDKit
from rdkit import Chem
from rdkit.Chem import PandasTools
#Saving to Excel
from openpyxl import load_workbook
from helper_functions import *
plt.rcParams['figure.figsize'] = [20,10]

print('Imports Done')
#Load in Data
scaffold_names = ['CYCLOHEXANE', 'CYCLOPENTANE', 'PIPERIDINE', 'PYRROLIDINE', 'PYRROLE', 'PYRAZOLE','IMIDAZOLE', 'INDOLE', 'INDAZOLE', 'PYRIDINE', 'PYRIMIDINE', 'PYRAZINE', 'QUINOLINE', 'BENZENE', 'NAPHTHALENE', 'FURAN', 'TETRAHYDOFURAN', 'TETRAHYDROPYRAN', 'THIOPHENE']
comprehensive_data = {'1200':{'Compound_#':[], 'Smiles':[], 'MOL':[], 'logReact':[], 'mtb':[], 'msm':[], 'has_ring':[], 'scaffolds':{}, 'fused':{}, 'non_fused':{}, 'props':{}}, 
                      '380':{'Compound_#':[], 'Smiles':[], 'MOL':[], 'logReact':[], 'mtb':[], 'msm':[], 'has_ring':[], 'scaffolds':{}, 'fused':{}, 'non_fused':{}, 'props':{}},
                      '40':{'Compound_#':[], 'Smiles':[], 'MOL':[], 'logReact':[], 'mtb':[], 'msm':[], 'has_ring':[], 'scaffolds':{}, 'fused':{}, 'non_fused':{}, 'props':{}}
                      }
msm_380 = pd.read_excel('380 library Msm whole cell final correction.xlsx', index_col=None, usecols="A,C,H,J")
mtb_380 = pd.read_csv('380_raw.csv', usecols=["#", "Smiles", "Mtb AVERAGE", "PS-DBCO "])

new_40 = pd.read_csv('20240719 Mtb and Msm az-40 data DEF for Turner.csv')
comp_data_1200 = pd.read_excel('20240516 Only MEAN - for CDD 1200 and 380.xlsx', index_col=None, usecols="G,F,H,I,J")

#Set up dataframe

#Combine 380 data
params = Chem.SmilesParserParams()
params.removeHs = True
smiles = '[H]N1C2=CC=CC=C2C=C1.[H]N1C2=NC=NC=C2N=C1.C1=CC=C2C(=C1)C=NN2.[H]N1C2=CC=CC=C2C=N1.C1=CC=C2C(=C1)C=CN2.CN1N=CC=C1.CN%12C=CC=C%12.CN%13C=CN=N%13.C%14%15=CC=CC=C%14OCO%15.C%16%17=CC=CC=C%16C=CC=C%17.C%18=CC=CO%18.C%19=CC=CS%19.C%20=CC=CN%20.C%21CCCCC%21.C%22CCCC%22.N%23CCCCC%23.N%24CCCC%24.C%25=CC=NO%25.N%26=NC=CN%26.C%27CC%27.C%28=CC=NN%28.O%29CCCCC%29.S%30CCCCC%30.O%31CCCC%31.O1C2=CC=CC=C2C=C1.C12=NC=CN1C=CC=C2.C1=CC=NC=N1.C12=NC=CC=C1NC=C2.CN1C=CC2=NC=CC=C21.C1=CN=CN1.'.split('.')
new_smiles = ['C1CCCCC1',
              'C1CCCC1',
              'N1CCCCC1',
              'N1CCCC1',
              'C1=CC=CN1',
              'C1=CC=NN1',
              'C1=NC=CN1',
              'C1=CC2=CC=CC=C2N1',
              'C1=CC=C2C(=C1)C=NN2',
              'C1=CC=CC=N1',
              'C1=CN=CN=C1',
              'C1=CN=CC=N1',
              'C1=CC=C2C(=C1)C=CC=N2',
              'C1=CC=CC=C1',
              'C1=CC=C2C=CC=CC2=C1',
              'C1=COC=C1',
              'C1CCOC1',
              'C1CCOCC1',
              'C1=CSC=C1'
              ]
substruct_patterns = {scaffold_names[i]: Chem.MolFromSmiles(new_smiles[i]) for i in range(len(new_smiles))}
for (key, mol) in substruct_patterns.items():
    column_name = key
    comprehensive_data['380']['scaffolds'][column_name] = []
    comprehensive_data['1200']['scaffolds'][column_name] = []
    comprehensive_data['40']['scaffolds'][column_name] = []
    comprehensive_data['380']['fused'][column_name] = []
    comprehensive_data['1200']['fused'][column_name] = []
    comprehensive_data['40']['fused'][column_name] = []
    comprehensive_data['380']['non_fused'][column_name] = []
    comprehensive_data['1200']['non_fused'][column_name] = []
    comprehensive_data['40']['non_fused'][column_name] = []

#Load 380
for index, row in enumerate(msm_380.iterrows()):
    try:
        if 'nan' not in [str(x) for x in row[1]]:

            mol_1 = Chem.MolFromSmiles(row[1][1].split(' ')[0])
            #display(mol_1)
            comprehensive_data['380']['Compound_#'].append(int(row[1][0]))
            comprehensive_data['380']['Smiles'].append(row[1][1].split(' ')[0])
            comprehensive_data['380']['logReact'].append(math.log(float(row[1][3]))/math.log(10))
            comprehensive_data['380']['msm'].append(float(row[1][2]))
            comprehensive_data['380']['MOL'].append(mol_1)
            comprehensive_data['380']['has_ring'].append(False)
            for key, sub_mol in substruct_patterns.items():
                comprehensive_data['380']['scaffolds'][key].append(False)
                comprehensive_data['380']['fused'][key].append(False)
                comprehensive_data['380']['non_fused'][key].append(False)
                result = is_scaffold_fused_in_molecule(mol_1, sub_mol)
                if result == 'fused':
                    comprehensive_data['380']['has_ring'][-1] = True
                    comprehensive_data['380']['scaffolds'][key][-1] = True
                    comprehensive_data['380']['fused'][key][-1] = True
                elif result == 'non_fused':
                    comprehensive_data['380']['has_ring'][-1] = True
                    comprehensive_data['380']['non_fused'][key][-1] = True
                    comprehensive_data['380']['scaffolds'][key][-1] = True
    except:
        print('Could not process ', row[1][1])
for index, row in enumerate(mtb_380.iterrows()):
    if int(row[1][0]) in comprehensive_data['380']['Compound_#']:
        comprehensive_data['380']['mtb'].append(float(row[1][3]))

#Load 40
for index, row in enumerate(new_40.iterrows()):
    try:
        if 'nan' not in [str(x) for x in row[1]]:
            mol_1 = Chem.MolFromSmiles(row[1][1].split(' ')[0])
            comprehensive_data['40']['Compound_#'].append(int(row[1][0][1:]))
            comprehensive_data['40']['Smiles'].append(row[1][1].split(' ')[0])
            comprehensive_data['40']['logReact'].append(float(row[1][5]))
            comprehensive_data['40']['msm'].append(float(row[1][3]))
            comprehensive_data['40']['mtb'].append(float(row[1][4]))
            comprehensive_data['40']['MOL'].append(mol_1)
            comprehensive_data['40']['has_ring'].append(False)
            for key, sub_mol in substruct_patterns.items():
                comprehensive_data['40']['scaffolds'][key].append(False)
                comprehensive_data['40']['fused'][key].append(False)
                comprehensive_data['40']['non_fused'][key].append(False)
                result = is_scaffold_fused_in_molecule(mol_1, sub_mol)
                if result == 'fused':
                    comprehensive_data['40']['has_ring'][-1] = True
                    comprehensive_data['40']['scaffolds'][key][-1] = True
                    comprehensive_data['40']['fused'][key][-1] = True
                elif result == 'non_fused':
                    comprehensive_data['40']['has_ring'][-1] = True
                    comprehensive_data['40']['non_fused'][key][-1] = True
                    comprehensive_data['40']['scaffolds'][key][-1] = True
    except:
        print('Could not process ', row[1][1])

#Load 1200
print(comp_data_1200.columns)
duplicate_count = 0
rows_as_series = comp_data_1200.to_dict(orient='records')

test_duplicate = {'mol':[Chem.MolFromSmiles(rows_as_series[0]['SMILES'].split(' ')[0].split('.')[0])], 'mtb':[float(rows_as_series[0]['Mtb_1200ave'])]}
duplicates = {'mols':[], 'mtb_vals':[]}
for i, row in enumerate(rows_as_series[1:]):
    if isinstance(row['SMILES'], str):

        mol = Chem.MolFromSmiles(row['SMILES'].split(' ')[0].split('.')[0])
        mtb = float(row['Mtb_1200ave'])
        dupl=False
        for j, mol_2 in enumerate(test_duplicate['mol']):
            if are_molecules_identical(mol, mol_2):

                duplicate_count += 1
                duplicates['mols'].append([mol, mol_2])
                duplicates['mtb_vals'].append([mtb, test_duplicate['mtb'][j]])
                dupl = True
                break
        if not dupl:
            test_duplicate['mol'].append(mol)
            test_duplicate['mtb'].append(mtb)
#Load 1200
for index, row in enumerate(comp_data_1200.iterrows()):
    try:
        if 'nan' not in [str(x) for x in row[1]]:
            mol_1 = Chem.MolFromSmiles(row[1][0].split(' ')[0].split('.')[0])
            comprehensive_data['1200']['Compound_#'].append(int(row[1][1]))
            comprehensive_data['1200']['Smiles'].append(row[1][0].split(' ')[0].split('.')[0])
            comprehensive_data['1200']['logReact'].append(math.log(float(row[1][4]))/math.log(10))
            comprehensive_data['1200']['msm'].append(float(row[1][2]))
            comprehensive_data['1200']['mtb'].append(float(row[1][3]))
            comprehensive_data['1200']['MOL'].append(mol_1)
            comprehensive_data['1200']['has_ring'].append(False)
            for key, sub_mol in substruct_patterns.items():
                comprehensive_data['1200']['scaffolds'][key].append(False)
                comprehensive_data['1200']['fused'][key].append(False)
                comprehensive_data['1200']['non_fused'][key].append(False)
                result = is_scaffold_fused_in_molecule(mol_1, sub_mol)
                if result == 'fused':
                    comprehensive_data['1200']['has_ring'][-1] = True
                    comprehensive_data['1200']['scaffolds'][key][-1] = True
                    comprehensive_data['1200']['fused'][key][-1] = True
                elif result == 'non_fused':
                    comprehensive_data['1200']['has_ring'][-1] = True
                    comprehensive_data['1200']['non_fused'][key][-1] = True
                    comprehensive_data['1200']['scaffolds'][key][-1] = True
    except:
        print('Could not process ', row[1][0])
print('Loaded in Data')
print('Plotting Analysis')
#Plot Raw permeability vs log(bead reactivity) - Mtb
plt.rcParams['font.size']=20

plt.title('Raw Permeability (Mtb) vs log(Bead Reactivity) - Base Ten')
a, b = np.polyfit(comprehensive_data['1200']['logReact'], comprehensive_data['1200']['mtb'], 1,)
plt.scatter(comprehensive_data['1200']['logReact'], comprehensive_data['1200']['mtb'], color='blue', alpha=0.5, label='1200')
plt.plot(comprehensive_data['1200']['logReact'], [a*i + b for i in comprehensive_data['1200']['logReact']], color='blue')
a, b = np.polyfit(comprehensive_data['380']['logReact'], comprehensive_data['380']['mtb'], 1)
plt.scatter(comprehensive_data['380']['logReact'], comprehensive_data['380']['mtb'], color='orange', alpha=0.5, label='380')
plt.plot(comprehensive_data['380']['logReact'], [a*i + b for i in comprehensive_data['380']['logReact']], color='orange')
a, b = np.polyfit(comprehensive_data['40']['logReact'], comprehensive_data['40']['mtb'], 1)
plt.scatter(comprehensive_data['40']['logReact'], comprehensive_data['40']['mtb'], color='red', alpha=0.5, label='40')
plt.plot(comprehensive_data['40']['logReact'], [a*i + b for i in comprehensive_data['40']['logReact']], color='red')
plt.xlabel('log(Bead Reactivity)')
plt.ylabel('Raw Permeability - Mtb')
plt.legend()
plt.tight_layout()
plt.savefig('./figures/mtb_raw_perm_vs_br.svg')
plt.clf()
#Plot Raw permeability vs log(bead reactivity) - Msm
plt.rcParams['font.size']=20

plt.title('Raw Permeability (Msm) vs log(Bead Reactivity) - Base Ten')
a, b = np.polyfit(comprehensive_data['1200']['logReact'], comprehensive_data['1200']['msm'], 1,)
plt.scatter(comprehensive_data['1200']['logReact'], comprehensive_data['1200']['msm'], color='blue', alpha=0.5, label='1200')
plt.plot(comprehensive_data['1200']['logReact'], [a*i + b for i in comprehensive_data['1200']['logReact']], color='blue')
a, b = np.polyfit(comprehensive_data['380']['logReact'], comprehensive_data['380']['msm'], 1)
plt.scatter(comprehensive_data['380']['logReact'], comprehensive_data['380']['msm'], color='orange', alpha=0.5, label='380')
plt.plot(comprehensive_data['380']['logReact'], [a*i + b for i in comprehensive_data['380']['logReact']], color='orange')
a, b = np.polyfit(comprehensive_data['40']['logReact'], comprehensive_data['40']['msm'], 1)
plt.scatter(comprehensive_data['40']['logReact'], comprehensive_data['40']['msm'], color='red', alpha=0.5, label='40')
plt.plot(comprehensive_data['40']['logReact'], [a*i + b for i in comprehensive_data['40']['logReact']], color='red')
plt.xlabel('log(Bead Reactivity)')
plt.ylabel('Raw Permeability - Msm')
plt.legend()
plt.tight_layout()
plt.savefig('./figures/msm_raw_perm_vs_br.svg')
plt.clf()
calc_residuals(comprehensive_data, '380')
calc_residuals(comprehensive_data, '40')
calc_residuals(comprehensive_data, '1200')

#Standardize Residuals
comprehensive_data['1200']['mtb_old_resid_std'] = [(x-np.nanmean(comprehensive_data['1200']['mtb_old_resid']))/np.nanstd(comprehensive_data['1200']['mtb_old_resid']) for x in comprehensive_data['1200']['mtb_old_resid']]
comprehensive_data['380']['mtb_old_resid_std'] = [(x-np.nanmean(comprehensive_data['380']['mtb_old_resid']))/np.nanstd(comprehensive_data['380']['mtb_old_resid']) for x in comprehensive_data['380']['mtb_old_resid']]
comprehensive_data['40']['mtb_old_resid_std'] = [(x-np.nanmean(comprehensive_data['40']['mtb_old_resid']))/np.nanstd(comprehensive_data['40']['mtb_old_resid']) for x in comprehensive_data['40']['mtb_old_resid']]
comprehensive_data['1200']['msm_old_resid_std'] = [(x-np.nanmean(comprehensive_data['1200']['msm_old_resid']))/np.nanstd(comprehensive_data['1200']['msm_old_resid']) for x in comprehensive_data['1200']['msm_old_resid']]
comprehensive_data['380']['msm_old_resid_std'] = [(x-np.nanmean(comprehensive_data['380']['msm_old_resid']))/np.nanstd(comprehensive_data['380']['msm_old_resid']) for x in comprehensive_data['380']['msm_old_resid']]
comprehensive_data['40']['msm_old_resid_std'] = [(x-np.nanmean(comprehensive_data['40']['msm_old_resid']))/np.nanstd(comprehensive_data['40']['msm_old_resid']) for x in comprehensive_data['40']['msm_old_resid']]
print(comprehensive_data['1200'].keys())
print('Saving raw data')

# Assuming comprehensive_data is structured as {1200: df1, 380: df2, 40: df3}
# where df1, df2, df3 are pandas DataFrames

# Specify the output Excel file name

output_filename = "./processed_data/comprehensive_data.xlsx"
raw_data = {}
for key in ['1200', '380', '40']:
    raw_data[key] = pd.DataFrame({'smiles': comprehensive_data[key]['Smiles'], 
                                  'logreact': comprehensive_data[key]['logReact'],
                                  'mtb_perm': comprehensive_data[key]['mtb'],
                                  'msm_perm': comprehensive_data[key]['msm'],
                                  'mtb_resid': comprehensive_data[key]['mtb_old_resid'],
                                  'msm_resid': comprehensive_data[key]['msm_old_resid'],
                                  'mtb_resid_std': comprehensive_data[key]['mtb_old_resid_std'],
                                  'msm_resid_std': comprehensive_data[key]['msm_old_resid_std']
                                  })
# Create an Excel writer object
with pd.ExcelWriter(output_filename, engine="openpyxl") as writer:
    for key, df in raw_data.items():
        df.to_excel(writer, sheet_name=str(key), index=False)  # Convert key to string for sheet name

print(f"Data saved successfully to {output_filename}")
#plot Mtb logReact vs normalized resid
plt.title('Mtb Standardized Residual vs log(Bead Reactivity)')
plt.ylabel('Mtb Standardized Residual')
plt.xlabel('log(Bead Reactivity) - Base 10')

a, b = np.polyfit(comprehensive_data['1200']['logReact'], comprehensive_data['1200']['mtb_old_resid_std'], 1)
plt.scatter(comprehensive_data['1200']['logReact'], comprehensive_data['1200']['mtb_old_resid_std'], color = 'blue', label = '1200', alpha=0.5)
plt.plot(comprehensive_data['1200']['logReact'], [a*i + b for i in comprehensive_data['1200']['logReact']], color='blue', linewidth=4)

a, b = np.polyfit(comprehensive_data['380']['logReact'], comprehensive_data['380']['mtb_old_resid_std'], 1)
plt.scatter(comprehensive_data['380']['logReact'], comprehensive_data['380']['mtb_old_resid_std'], color = 'orange', label = '380', alpha=0.5)
plt.plot(comprehensive_data['380']['logReact'], [a*i + b for i in comprehensive_data['380']['logReact']], color='orange', linewidth=4)

a, b = np.polyfit(comprehensive_data['40']['logReact'], comprehensive_data['40']['mtb_old_resid_std'], 1)
plt.scatter(comprehensive_data['40']['logReact'], comprehensive_data['40']['mtb_old_resid_std'], color = 'red', label = '40', alpha=0.5)
plt.plot(comprehensive_data['40']['logReact'], [a*i + b for i in comprehensive_data['40']['logReact']], color='red', linewidth = 4)
plt.legend()
plt.tight_layout()
plt.savefig('./figures/mtb_std_resid_vs_br.svg')
plt.clf()
#plot Mtb logReact vs normalized resid
plt.title('Msm Standardized Residual vs log(Bead Reactivity)')
plt.ylabel('Msm Standardized Residual')
plt.xlabel('log(Bead Reactivity) - Base 10')

a, b = np.polyfit(comprehensive_data['1200']['logReact'], comprehensive_data['1200']['msm_old_resid_std'], 1)
plt.scatter(comprehensive_data['1200']['logReact'], comprehensive_data['1200']['msm_old_resid_std'], color = 'blue', label = '1200', alpha=0.5)
plt.plot(comprehensive_data['1200']['logReact'], [a*i + b for i in comprehensive_data['1200']['logReact']], color='blue', linewidth=4)

a, b = np.polyfit(comprehensive_data['380']['logReact'], comprehensive_data['380']['msm_old_resid_std'], 1)
plt.scatter(comprehensive_data['380']['logReact'], comprehensive_data['380']['msm_old_resid_std'], color = 'orange', label = '380', alpha=0.5)
plt.plot(comprehensive_data['380']['logReact'], [a*i + b for i in comprehensive_data['380']['logReact']], color='orange', linewidth=4)

a, b = np.polyfit(comprehensive_data['40']['logReact'], comprehensive_data['40']['mtb_old_resid_std'], 1)
plt.scatter(comprehensive_data['40']['logReact'], comprehensive_data['40']['msm_old_resid_std'], color = 'red', label = '40', alpha=0.5)
plt.plot(comprehensive_data['40']['logReact'], [a*i + b for i in comprehensive_data['40']['logReact']], color='red', linewidth = 4)
plt.legend()
plt.tight_layout()
plt.savefig('./figures/msm_std_resid_vs_br.svg')
plt.clf()
#Convert to One DataFrame
for library in ['40', '380', '1200']:
    for scaff_name in comprehensive_data[library]['scaffolds'].keys():
        comprehensive_data[library][scaff_name] = comprehensive_data[library]['scaffolds'][scaff_name]
        comprehensive_data[library][scaff_name+'_fused'] = comprehensive_data[library]['fused'][scaff_name]
        comprehensive_data[library][scaff_name+'_non_fused'] = comprehensive_data[library]['non_fused'][scaff_name]

params = Chem.SmilesParserParams()
params.removeHs = True

mol = Chem.MolFromSmiles("C[H]", params)

substruct_patterns = {scaffold_names[i]: Chem.MolFromSmiles(new_smiles[i]) for i in range(len(new_smiles))}

#Plot eNTRy mol per library - mtb
entry_mtb_resid = {'1200':[], '380':[], '40':[]}
for library in ['1200', '380', '40']:
    for i, mol in enumerate(comprehensive_data[library]['MOL']):
        if check_entry(mol):
            entry_mtb_resid[library].append(comprehensive_data[library]['mtb_old_resid_std'][i])
data = [entry_mtb_resid['1200'], entry_mtb_resid['380'], entry_mtb_resid['40']]
fig, ax = plt.subplots()
parts = ax.violinplot(data)
parts['bodies'][0].set_facecolor('skyblue')
parts['bodies'][1].set_facecolor('orange')
parts['bodies'][2].set_facecolor('red')
counts = [len(entry_mtb_resid['1200']), len(entry_mtb_resid['380']), len(entry_mtb_resid['40'])]
for i, count in enumerate(counts):
    # Position above the max y value for the current x value
    ax.text(i+1, 1.5, f'{count}', 
            ha='center', va='bottom', color='black')
ax.set_ylabel('Standardized Mtb Residual')
ax.set_xticks(range(1,4), labels=list(entry_mtb_resid.keys()))
ax.set_ylim(-3.5,2)
fig.suptitle('Mtb Standardized Residual - mols that satisfy eNTRy')
fig.tight_layout()
fig.savefig('./figures/eNTRy_mols_per_lib_mtb.svg')
plt.clf()
entry_msm_std = {'1200':[], '380':[], '40':[]}
for library in ['1200', '380', '40']:
    for i, mol in enumerate(comprehensive_data[library]['MOL']):
        if check_entry(mol):
            entry_msm_std[library].append(comprehensive_data[library]['msm_old_resid_std'][i])


data = [entry_msm_std['1200'], entry_msm_std['380'], entry_msm_std['40']]
fig, ax = plt.subplots()
parts = ax.violinplot(data)
parts['bodies'][0].set_facecolor('skyblue')
parts['bodies'][1].set_facecolor('orange')
parts['bodies'][2].set_facecolor('red')
counts = [len(entry_msm_std['1200']), len(entry_msm_std['380']), len(entry_msm_std['40'])]
for i, count in enumerate(counts):
    # Position above the max y value for the current x value
    ax.text(i+1, 1.25, f'{count}', 
            ha='center', va='bottom', color='black')
ax.set_ylabel('Msm Standardized Residual')
ax.set_ylim(-3.5,2)
ax.set_xticks(range(1,4), labels=list(entry_mtb_resid.keys()))
fig.suptitle('Msm Standardized Residual - mols that satisfy eNTRy')
fig.tight_layout()

#Plot Lipinski mols per library - mtb
lipinski_mtb_resid = {'1200':[], '380':[], '40':[]}
for library in ['1200', '380', '40']:
    for i, mol in enumerate(comprehensive_data[library]['MOL']):
        if check_lipinski(mol):
            lipinski_mtb_resid[library].append(comprehensive_data[library]['mtb_old_resid_std'][i])
data = [lipinski_mtb_resid['1200'], lipinski_mtb_resid['380'], lipinski_mtb_resid['40']]
fig, ax = plt.subplots()
parts = ax.violinplot(data)
parts['bodies'][0].set_facecolor('skyblue')
parts['bodies'][1].set_facecolor('orange')
parts['bodies'][2].set_facecolor('red')
counts = [len(lipinski_mtb_resid['1200']), len(lipinski_mtb_resid['380']), len(lipinski_mtb_resid['40'])]
for i, count in enumerate(counts):
    # Position above the max y value for the current x value
    ax.text(i+1, 2.0, f'{count}', 
            ha='center', va='bottom', color='black')
ax.set_ylabel('Standardized Mtb Residual')
ax.set_xticks(range(1,4), labels=list(entry_mtb_resid.keys()))
ax.set_ylim(-3.5,2)
fig.suptitle('Mtb Standardized Residual - mols that satisfy Lipinski')
fig.tight_layout()
fig.savefig('./figures/lipinski_mols_per_lib_mtb.svg')
plt.clf()
#Plot Lipinski mols per library - msm
lipinski_msm_resid = {'1200':[], '380':[], '40':[]}
for library in ['1200', '380', '40']:
    for i, mol in enumerate(comprehensive_data[library]['MOL']):
        if check_lipinski(mol):
            lipinski_msm_resid[library].append(comprehensive_data[library]['msm_old_resid_std'][i])

data = [lipinski_msm_resid['1200'], lipinski_msm_resid['380'], lipinski_msm_resid['40']]
fig, ax = plt.subplots()
parts = ax.violinplot(data)
parts['bodies'][0].set_facecolor('skyblue')
parts['bodies'][1].set_facecolor('orange')
parts['bodies'][2].set_facecolor('red')
counts = [len(lipinski_msm_resid['1200']), len(lipinski_msm_resid['380']), len(lipinski_msm_resid['40'])]
for i, count in enumerate(counts):
    # Position above the max y value for the current x value
    ax.text(i+1, 2.0, f'{count}', 
            ha='center', va='bottom', color='black')
ax.set_ylabel('Standardized Msm Residual')
ax.set_xticks(range(1,4), labels=list(entry_mtb_resid.keys()))
fig.suptitle('Msm Standardized Residual - mols that satisfy Lipinski')
ax.set_ylim(-3.5,2)
fig.tight_layout()
fig.savefig('./figures/lipinski_mols_per_lib_msm.svg')
plt.clf()

#Plot TPSA
for library in ['1200', '380', '40']:
    tpsa = []
    for mol in comprehensive_data[library]['MOL']:
        tpsa.append(calculate_tpsa(mol))
    plt.scatter(tpsa, comprehensive_data[library]['mtb_old_resid_std'])
plt.xlabel('TPSA')
plt.ylabel('Mtb Standardized Residual')
plt.tight_layout()
plt.savefig('./figures/tpsa_vs_std_resid_mtb.svg')
plt.clf()
for library in ['1200', '380', '40']:
    tpsa = []
    for mol in comprehensive_data[library]['MOL']:
        tpsa.append(calculate_tpsa(mol))
    plt.scatter(tpsa, comprehensive_data[library]['mtb'])
plt.xlabel('TPSA')
plt.ylabel('Mtb Raw Permeability')
plt.tight_layout()
plt.savefig('./figures/tpsa_vs_raw_perm_mtb.svg')
plt.clf()

#Plot logP
for library in ['1200', '380', '40']:
    logp = []
    for mol in comprehensive_data[library]['MOL']:
        logp.append(calculate_logp(mol))
    plt.scatter(logp, comprehensive_data[library]['mtb_old_resid_std'])
plt.xlabel('logP (from RDKit.Crippen)')
plt.ylabel('Mtb Standardized Residual')
plt.tight_layout()
plt.savefig('./figures/logp_vs_std_resid_mtb.svg')
plt.clf()
for library in ['1200', '380', '40']:
    logp = []
    for mol in comprehensive_data[library]['MOL']:
        logp.append(calculate_logp(mol))
    plt.scatter(logp, comprehensive_data[library]['mtb'])
plt.xlabel('logP (from RDKit.Crippen)')
plt.ylabel('Mtb Raw Permeability')
plt.tight_layout()
plt.savefig('./figures/logp_vs_raw_perm_mtb.svg')
plt.clf()

#Plot Permeability measures by ring name
plt.rcParams['figure.figsize'] = [20,10]
#380 scaffold violins - Raw data
#Mtb
plt.rcParams['font.size'] = 15
labels = list(comprehensive_data['380']['scaffolds'].keys())
labels.append('All')
data=[]
for label, scaff_list in comprehensive_data['380']['scaffolds'].items():
    data.append(list(compress(comprehensive_data['380']['mtb'], scaff_list)))
    
data.append(pd.Series(comprehensive_data['380']['mtb']))
for index, l in enumerate(data[:-1]):
    if len(l) == 0:
        data[index] = [0]
plt.violinplot(data, positions = [x-0.45 for x in range(0,40,2)])
plt.boxplot(data, positions = [x-0.45 for x in range(0,40,2)])

data=[]
for label, scaff_list in comprehensive_data['380']['scaffolds'].items():
    data.append(list(compress(comprehensive_data['380']['msm'], scaff_list)))
data.append(pd.Series(comprehensive_data['380']['msm']).dropna())
for index, l in enumerate(data[:-1]):
    if len(l) == 0:
        data[index] = [0]
plt.violinplot(data, positions = [x+0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])
plt.boxplot(data, positions = [x+0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])
plt.xticks(range(0,(len(scaffold_names) + 1) *2,2), labels, rotation=85)
mean = np.nanmean(comprehensive_data['380']['msm'])
plt.plot(range(0,(len(scaffold_names) + 1) *2), [mean for i in range(0,(len(scaffold_names) + 1) *2)], color='orange')
mean = np.average(comprehensive_data['380']['mtb'])
plt.plot(range(0,(len(scaffold_names) + 1) *2), [mean for i in range(0,(len(scaffold_names) + 1) *2)], color='blue')
plt.xlabel('Ring Name')
plt.ylabel('Raw Permeability')
plt.title('Raw Permeability by Ring Name - 380 library')
legend_elements = [Patch(facecolor='skyblue', edgecolor='black',
                         label='Mtb'),
                   Line2D([0], [0], color='blue', label='Avg Mtb'),
                   Patch(facecolor='orange', edgecolor='black',
                         label='Msm'),
                   Line2D([0], [0], color='orange', label='Avg Msm'),
                         ]
plt.legend(handles=legend_elements)
plt.tight_layout()
plt.savefig('./figures/raw_perm_by_ring_380.svg')
plt.clf()
#1200 scaffold violins - Raw data

#Mtb
plt.rcParams['font.size'] = 15
labels = list(comprehensive_data['1200']['scaffolds'].keys())
labels.append('All')
data=[]
for label, scaff_list in comprehensive_data['1200']['scaffolds'].items():
    data.append(pd.Series(list(compress(comprehensive_data['1200']['mtb'], scaff_list))).dropna())
data.append(pd.Series(comprehensive_data['1200']['mtb']).dropna())
for index, l in enumerate(data[:-1]):
    if len(l) == 0:
        data[index] = [0]
plt.violinplot(data, positions = [x-0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])
plt.boxplot(data, positions = [x-0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])

data=[]
for label, scaff_list in comprehensive_data['1200']['scaffolds'].items():
    data.append(pd.Series(list(compress(comprehensive_data['1200']['msm'], scaff_list))).dropna())
data.append(pd.Series(comprehensive_data['1200']['msm']).dropna())
for index, l in enumerate(data[:-1]):
    if len(l) == 0:
        data[index] = [0]
plt.violinplot(data, positions = [x+0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])
plt.boxplot(data, positions = [x+0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])
plt.xticks(range(0,(len(scaffold_names) + 1) *2,2), labels, rotation=85)
mean = np.average(comprehensive_data['1200']['msm'])
plt.plot(range(0,(len(scaffold_names) + 1) *2), [mean for i in range(0,(len(scaffold_names) + 1) *2)], color='orange')
mean = np.nanmean(comprehensive_data['1200']['mtb'])
plt.plot(range(0,(len(scaffold_names) + 1) *2), [mean for i in range(0,(len(scaffold_names) + 1) *2)], color='blue')
plt.title('Raw Permeability by Ring - 1200 library')
plt.xlabel('Ring Name')
plt.ylabel('Raw Permeability')
legend_elements = [Patch(facecolor='skyblue', edgecolor='black',
                         label='Mtb'),
                   Line2D([0], [0], color='blue', label='Avg Mtb'),
                   Patch(facecolor='orange', edgecolor='black',
                         label='Msm'),
                   Line2D([0], [0], color='orange', label='Avg Msm'),
                         ]
plt.legend(handles=legend_elements)
plt.tight_layout()
plt.savefig('./figures/raw_perm_by_ring_1200.svg')
plt.clf()
#Mtb
plt.rcParams['font.size'] = 15
labels = list(comprehensive_data['40']['scaffolds'].keys())
labels.append('All')
data=[]
for label, scaff_list in comprehensive_data['40']['scaffolds'].items():
    data.append(list(compress(comprehensive_data['40']['mtb'], scaff_list)))
    
data.append(pd.Series(comprehensive_data['40']['mtb']))
for index, l in enumerate(data[:-1]):
    if len(l) == 0:
        data[index] = [0]
plt.violinplot(data, positions = [x-0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])
plt.boxplot(data, positions = [x-0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])

data=[]
for label, scaff_list in comprehensive_data['40']['scaffolds'].items():
    data.append(list(compress(comprehensive_data['40']['msm'], scaff_list)))
data.append(pd.Series(comprehensive_data['40']['msm']).dropna())
for index, l in enumerate(data[:-1]):
    if len(l) == 0:
        data[index] = [0]
plt.violinplot(data, positions = [x+0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])
plt.boxplot(data, positions = [x+0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])
plt.xticks(range(0,(len(scaffold_names) + 1) *2,2), labels, rotation=85)
mean = np.nanmean(comprehensive_data['40']['msm'])
plt.plot(range(0,(len(scaffold_names) + 1) *2), [mean for i in range(0,(len(scaffold_names) + 1) *2)], color='orange')
mean = np.average(comprehensive_data['40']['mtb'])
plt.plot(range(0,(len(scaffold_names) + 1) *2), [mean for i in range(0,(len(scaffold_names) + 1) *2)], color='blue')
plt.xlabel('Ring Name')
plt.ylabel('Raw Permeability')
plt.title('Raw Permeability by Ring - 40 library')
legend_elements = [Patch(facecolor='skyblue', edgecolor='black',
                         label='Mtb'),
                   Line2D([0], [0], color='blue', label='Avg Mtb'),
                   Patch(facecolor='orange', edgecolor='black',
                         label='Msm'),
                   Line2D([0], [0], color='orange', label='Avg Msm'),
                         ]
plt.legend(handles=legend_elements)
plt.tight_layout()
plt.savefig('./figures/raw_perm_by_ring_40.svg')
plt.clf()

means = []
plt.rcParams['font.size'] = 15
labels = list(comprehensive_data['380']['scaffolds'].keys())
labels.append('All')

data = []
scaffolds_380_mtb_std = {}
scaffolds_380_msm_std = {}
scaffolds_1200_mtb_std = {}
scaffolds_1200_msm_std = {}
scaffolds_40_mtb_std = {}
scaffolds_40_msm_std = {}

# 1200 Library
for label, scaff_list in comprehensive_data['1200']['scaffolds'].items():
    data.append(list(compress(comprehensive_data['1200']['mtb'], scaff_list)))
data.append(pd.Series(comprehensive_data['1200']['mtb']).dropna())
means.append(np.nanmean(comprehensive_data['1200']['mtb']))

for index, l in enumerate(data[:-1]):
    if len(l) == 0:
        data[index] = [0]
        
violin_parts = plt.violinplot(data, positions=[x-0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])
for pc in violin_parts['bodies']:
    pc.set_facecolor('skyblue')
plt.boxplot(data, positions=[x-0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])

# Adding counts above each violin plot
for i, d in enumerate(data):
    plt.text(i*2 - 0.45, 1.2, str(len(d)), ha='center', va='bottom', fontsize=10, color='blue')

# 380 Library
data = []
for label, scaff_list in comprehensive_data['380']['scaffolds'].items():
    data.append(list(compress(comprehensive_data['380']['mtb'], scaff_list)))
data.append(pd.Series(comprehensive_data['380']['mtb']).dropna())
means.append(np.nanmean(comprehensive_data['380']['mtb']))

for index, l in enumerate(data[:-1]):
    if len(l) == 0:
        data[index] = [0]
        
violin_parts = plt.violinplot(data, positions=[x for x in range(0,(len(scaffold_names) + 1) *2,2)])
for pc in violin_parts['bodies']:
    pc.set_facecolor('orange')
plt.boxplot(data, positions=[x for x in range(0,(len(scaffold_names) + 1) *2,2)])

# Adding counts above each violin plot
for i, d in enumerate(data):
    plt.text(i*2, 1.2, str(len(d)), ha='center', va='bottom', fontsize=10, color='orange')

# 40 Library
data = []
for label, scaff_list in comprehensive_data['40']['scaffolds'].items():
    data.append(list(compress(comprehensive_data['40']['mtb'], scaff_list)))
data.append(pd.Series(comprehensive_data['40']['mtb']).dropna())
means.append(np.nanmean(comprehensive_data['40']['mtb']))

for index, l in enumerate(data[:-1]):
    if len(l) == 0:
        data[index] = [0]
        
violin_parts = plt.violinplot(data, positions=[x+0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])
for pc in violin_parts['bodies']:
    pc.set_facecolor('red')
plt.boxplot(data, positions=[x+0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])

# Adding counts above each violin plot
for i, d in enumerate(data):
    plt.text(i*2 + 0.45, 1.2, str(len(d)), ha='center', va='bottom', fontsize=10, color='red')

# Plot configuration
plt.xticks(range(0,(len(scaffold_names) + 1) *2,2), labels, rotation=85)
plt.xlabel('Ring Name')
plt.ylabel('Raw Permeability')
plt.title('Raw Permeability by Ring Name - all three libraries')
legend_elements = [Patch(facecolor='skyblue', edgecolor='black', label='1200'),
                   Patch(facecolor='orange', edgecolor='black', label='380'),
                   Patch(facecolor='red', edgecolor='black', label='40')]
plt.legend(handles=legend_elements)

plt.plot([i for i in range(0,(len(scaffold_names) + 1) *2)], [means[0] for i in range(0,(len(scaffold_names) + 1) *2)], color='skyblue', linestyle='--')
plt.plot([i for i in range(0,(len(scaffold_names) + 1) *2)], [means[1] for i in range(0,(len(scaffold_names) + 1) *2)], color='orange', linestyle='--')
plt.plot([i for i in range(0,(len(scaffold_names) + 1) *2)], [means[2] for i in range(0,(len(scaffold_names) + 1) *2)], color='red', linestyle='--')
plt.tight_layout()
plt.savefig('./figures/mtb_raw_perm_by_ring_all_libs.svg')
plt.clf()

means = []
plt.rcParams['font.size'] = 15
labels = list(comprehensive_data['380']['scaffolds'].keys())
labels.append('All')

data = []
scaffolds_380_mtb_std = {}
scaffolds_380_msm_std = {}
scaffolds_1200_mtb_std = {}
scaffolds_1200_msm_std = {}
scaffolds_40_mtb_std = {}
scaffolds_40_msm_std = {}

# 1200 Library
for label, scaff_list in comprehensive_data['1200']['scaffolds'].items():
    data.append(list(compress(comprehensive_data['1200']['mtb_old_resid_std'], scaff_list)))
    scaffolds_1200_msm_std[label] = list(compress(comprehensive_data['1200']['msm_old_resid_std'], scaff_list))
    scaffolds_1200_mtb_std[label] = list(compress(comprehensive_data['1200']['mtb_old_resid_std'], scaff_list))
data.append(pd.Series(comprehensive_data['1200']['mtb_old_resid_std']).dropna())
means.append(np.nanmean(comprehensive_data['1200']['mtb_old_resid_std']))

for index, l in enumerate(data[:-1]):
    if len(l) == 0:
        data[index] = [0]
        
violin_parts = plt.violinplot(data, positions=[x-0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])
for pc in violin_parts['bodies']:
    pc.set_facecolor('skyblue')
plt.boxplot(data, positions=[x-0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])

# Adding counts above each violin plot
for i, d in enumerate(data):
    plt.text(i*2 - 0.45, 1.5, str(len(d)), ha='center', va='bottom', fontsize=10, color='blue')

# 380 Library
data = []
for label, scaff_list in comprehensive_data['380']['scaffolds'].items():
    data.append(list(compress(comprehensive_data['380']['mtb_old_resid_std'], scaff_list)))
    scaffolds_380_msm_std[label] = list(compress(comprehensive_data['380']['msm_old_resid_std'], scaff_list))
    scaffolds_380_mtb_std[label] = list(compress(comprehensive_data['380']['mtb_old_resid_std'], scaff_list))
data.append(pd.Series(comprehensive_data['380']['mtb_old_resid_std']).dropna())
means.append(np.nanmean(comprehensive_data['380']['mtb_old_resid_std']))

for index, l in enumerate(data[:-1]):
    if len(l) == 0:
        data[index] = [0]
        
violin_parts = plt.violinplot(data, positions=[x for x in range(0,(len(scaffold_names) + 1) *2,2)])
for pc in violin_parts['bodies']:
    pc.set_facecolor('orange')
plt.boxplot(data, positions=[x for x in range(0,(len(scaffold_names) + 1) *2,2)])

# Adding counts above each violin plot
for i, d in enumerate(data):
    plt.text(i*2, 1.5, str(len(d)), ha='center', va='bottom', fontsize=10, color='orange')

# 40 Library
data = []
for label, scaff_list in comprehensive_data['40']['scaffolds'].items():
    data.append(list(compress(comprehensive_data['40']['mtb_old_resid_std'], scaff_list)))
    scaffolds_40_msm_std[label] = list(compress(comprehensive_data['40']['msm_old_resid_std'], scaff_list))
    scaffolds_40_mtb_std[label] = list(compress(comprehensive_data['40']['mtb_old_resid_std'], scaff_list))
data.append(pd.Series(comprehensive_data['40']['mtb_old_resid_std']).dropna())
means.append(np.nanmean(comprehensive_data['40']['mtb_old_resid_std']))

for index, l in enumerate(data[:-1]):
    if len(l) == 0:
        data[index] = [0]
        
violin_parts = plt.violinplot(data, positions=[x+0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])
for pc in violin_parts['bodies']:
    pc.set_facecolor('red')
plt.boxplot(data, positions=[x+0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])

# Adding counts above each violin plot
for i, d in enumerate(data):
    plt.text(i*2 + 0.45, 1.5, str(len(d)), ha='center', va='bottom', fontsize=10, color='red')

# Plot configuration
plt.xticks(range(0,(len(scaffold_names) + 1) *2,2), labels, rotation=85)
plt.xlabel('Ring Name')
plt.ylabel('Standardized Residual')
plt.title('Standardized Residual by Ring Name - all three libraries')
legend_elements = [Patch(facecolor='skyblue', edgecolor='black', label='1200'),
                   Patch(facecolor='orange', edgecolor='black', label='380'),
                   Patch(facecolor='red', edgecolor='black', label='40')]
plt.legend(handles=legend_elements)

plt.plot([i for i in range(0,(len(scaffold_names) + 1) *2)], [means[0] for i in range(0,(len(scaffold_names) + 1) *2)], color='skyblue', linestyle='--')
plt.plot([i for i in range(0,(len(scaffold_names) + 1) *2)], [means[1] for i in range(0,(len(scaffold_names) + 1) *2)], color='orange', linestyle='--')
plt.plot([i for i in range(0,(len(scaffold_names) + 1) *2)], [means[2] for i in range(0,(len(scaffold_names) + 1) *2)], color='red', linestyle='--')
plt.tight_layout()
plt.savefig('./figures/mtb_std_resid_by_ring_all_libs.svg')
plt.clf()
#Common Molecules
# Load datasets - Residuals
df_1200 = pd.DataFrame({'smiles':list(comprehensive_data['1200']['Smiles']), 'resid':list([x for x in comprehensive_data['1200']['mtb_old_resid_std']])})
df_380 = pd.DataFrame({'smiles':list(comprehensive_data['380']['Smiles']), 'resid':list([x for x in comprehensive_data['380']['mtb_old_resid_std']])})
df_40 = pd.DataFrame({'smiles':list(comprehensive_data['40']['Smiles']), 'resid':list([x for x in comprehensive_data['40']['mtb_old_resid_std']])})

# Convert SMILES to canonical form and create new columns for canonical SMILES
df_1200['canonical_smiles'] = df_1200['smiles'].apply(canonicalize_smiles)
df_380['canonical_smiles'] = df_380['smiles'].apply(canonicalize_smiles)
df_40['canonical_smiles'] = df_40['smiles'].apply(canonicalize_smiles)

# Extract canonical SMILES and permeability columns
df_1200 = df_1200[['canonical_smiles', 'resid']].rename(columns={'resid': 'std_resid_1200'})
df_380 = df_380[['canonical_smiles', 'resid']].rename(columns={'resid': 'std_resid_380'})
df_40 = df_40[['canonical_smiles', 'resid']].rename(columns={'resid': 'std_resid_40'})

# Create sets of canonical SMILES
canonical_smiles1 = set(df_1200['canonical_smiles'])
canonical_smiles2 = set(df_380['canonical_smiles'])
canonical_smiles3 = set(df_40['canonical_smiles'])

# Find common canonical SMILES across at least two datasets
common_canonical_smiles = (canonical_smiles1 & canonical_smiles2) | (canonical_smiles1 & canonical_smiles3) | (canonical_smiles2 & canonical_smiles3)
# Filter datasets to include only common canonical SMILES
df_1200_filtered = df_1200[df_1200['canonical_smiles'].isin(common_canonical_smiles)]
df_380_filtered = df_380[df_380['canonical_smiles'].isin(common_canonical_smiles)]
df_40_filtered = df_40[df_40['canonical_smiles'].isin(common_canonical_smiles)]

# Merge datasets on canonical SMILES
result_df = pd.merge(df_1200_filtered, df_380_filtered, on='canonical_smiles', how='outer')
result_df = pd.merge(result_df, df_40_filtered, on='canonical_smiles', how='outer')

# Optionally convert canonical SMILES back to original SMILES if needed
# result_df['smiles'] = result_df['canonical_smiles'].apply(lambda x: Chem.MolToSmiles(Chem.MolFromSmiles(x), isomericSmiles=True))

# Save the result
result_df.to_csv('./processed_data/20241104_common_mols.csv', index=False)

sns.set(font_scale=2)
count = 0
full_count = 0
diff = []
plt.rcParams['font.size'] = 30
for index, row in enumerate(result_df.iterrows()):
    full_count += 1
    plt.plot([index for x in range(-3,3)], [x for x in range(-3,3)], linestyle='--', alpha=0.5, color='grey')
    diff.append(row[1][1] - row[1][2])
    plt.scatter(index, row[1][1], color = 'blue')
    plt.scatter(index, row[1][2], color = 'orange')
    plt.scatter(index, row[1][3], color = 'red')
    legend_elements = [Line2D([0], [0], marker='o', color='red', label='40'),
                   Line2D([0], [0], marker='o', color='orange', label='380'),
                   Line2D([0], [0], marker='o', color='blue', label='1200')
                   ]
plt.legend(handles=legend_elements)
plt.ylabel('Standardized Residuals')
plt.xlabel('Molecule #')
plt.title('Comparison of Standardized Residuals for common molecules')
plt.tight_layout()
plt.savefig('./figures/mtb_std_resid_common_mols_comp.svg')
plt.clf()


plt.rcParams['font.size'] = 15
labels = list(comprehensive_data['380']['scaffolds'].keys())
labels.append('All')
means = []
data=[]
for label, scaff_list in comprehensive_data['1200']['fused'].items():
    data.append(list(compress(comprehensive_data['1200']['mtb_old_resid_std'], scaff_list)))
data.append(pd.Series(comprehensive_data['1200']['mtb_old_resid_std']).dropna())
means.append(np.nanmean(comprehensive_data['1200']['mtb_old_resid_std']))
for index, l in enumerate(data[:-1]):
    if len(l) == 0:
        data[index] = [0]
plt.violinplot(data, positions = [x-0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])
plt.boxplot(data, positions = [x-0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])

data=[]
for label, scaff_list in comprehensive_data['380']['fused'].items():
    data.append(list(compress(comprehensive_data['380']['mtb_old_resid_std'], scaff_list)))
data.append(pd.Series(comprehensive_data['380']['mtb_old_resid_std']).dropna())
means.append(np.nanmean(comprehensive_data['380']['mtb_old_resid_std']))
for index, l in enumerate(data[:-1]):
    if len(l) == 0:
        data[index] = [0]
plt.violinplot(data, positions = [x for x in range(0,(len(scaffold_names) + 1) *2,2)])
plt.boxplot(data, positions = [x for x in range(0,(len(scaffold_names) + 1) *2,2)])

data=[]
for label, scaff_list in comprehensive_data['40']['fused'].items():
    data.append(list(compress(comprehensive_data['40']['mtb_old_resid_std'], scaff_list)))
data.append(pd.Series(comprehensive_data['40']['mtb_old_resid_std']).dropna())
means.append(np.nanmean(comprehensive_data['40']['mtb_old_resid_std']))
for index, l in enumerate(data[:-1]):
    if len(l) == 0:
        data[index] = [0]
plt.violinplot(data, positions = [x+0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])
plt.boxplot(data, positions = [x+0.45 for x in range(0,(len(scaffold_names) + 1) *2,2)])

plt.xticks(range(0,(len(scaffold_names) + 1) *2,2), labels, rotation=85)
plt.xlabel('Ring Name')
plt.ylabel('Standardized Residual')
plt.title('Standardized Residual by Ring Name - Only Fused Scaffolds')
legend_elements = [Patch(facecolor='skyblue', edgecolor='black',
                         label='1200'),
                   Patch(facecolor='orange', edgecolor='black',
                         label='380'),
                   Patch(facecolor='green', edgecolor='black',
                         label='40')
                         ]
plt.plot([i for i in range(0,(len(scaffold_names) + 1) *2)], [means[0] for i in range(0,(len(scaffold_names) + 1) *2)], color = 'skyblue', linestyle = '--', alpha = 0.5)
plt.plot([i for i in range(0,(len(scaffold_names) + 1) *2)], [means[1] for i in range(0,(len(scaffold_names) + 1) *2)], color = 'orange', linestyle = '--', alpha = 0.5)
plt.plot([i for i in range(0,(len(scaffold_names) + 1) *2)], [means[2] for i in range(0,(len(scaffold_names) + 1) *2)], color = 'red', linestyle = '--', alpha = 0.5)
plt.legend(handles=legend_elements)
plt.tight_layout()
plt.savefig('./figures/mtb_std_resid_by_ring_fused.svg')
plt.clf()

# Set up font size
plt.rcParams['font.size'] = 15

# Prepare labels
labels = list(comprehensive_data['380']['scaffolds'].keys())
labels.append('All')

# First data set - 1200
data_1200 = []
for label, scaff_list in comprehensive_data['1200']['non_fused'].items():
    data_1200.append(list(compress(comprehensive_data['1200']['msm_old_resid_std'], scaff_list)))
data_1200.append(pd.Series(comprehensive_data['1200']['msm_old_resid_std']).dropna())
for index, l in enumerate(data_1200[:-1]):
    if len(l) == 0:
        data_1200[index] = [0]
violin_1200 = plt.violinplot(data_1200, positions=[x-0.45 for x in range(0, (len(scaffold_names) + 1) *2, 2)])
plt.boxplot(data_1200, positions=[x-0.45 for x in range(0, (len(scaffold_names) + 1) *2, 2)])

# Set color for 1200 dataset violins
for pc in violin_1200['bodies']:
    pc.set_facecolor('cyan')
    pc.set_edgecolor('black')
    pc.set_alpha(0.7)

# Second data set - 380
data_380 = []
for label, scaff_list in comprehensive_data['380']['non_fused'].items():
    data_380.append(list(compress(comprehensive_data['380']['msm_old_resid_std'], scaff_list)))
data_380.append(pd.Series(comprehensive_data['380']['msm_old_resid_std']).dropna())
for index, l in enumerate(data_380[:-1]):
    if len(l) == 0:
        data_380[index] = [0]
violin_380 = plt.violinplot(data_380, positions=[x for x in range(0, (len(scaffold_names) + 1) *2, 2)])
plt.boxplot(data_380, positions=[x for x in range(0, (len(scaffold_names) + 1) *2, 2)])

# Set color for 380 dataset violins
for pc in violin_380['bodies']:
    pc.set_facecolor('orange')
    pc.set_edgecolor('black')
    pc.set_alpha(0.7)

# Third data set - 40
data_40 = []
for label, scaff_list in comprehensive_data['40']['non_fused'].items():
    data_40.append(list(compress(comprehensive_data['40']['msm_old_resid_std'], scaff_list)))
data_40.append(pd.Series(comprehensive_data['40']['msm_old_resid_std']).dropna())
for index, l in enumerate(data_40[:-1]):
    if len(l) == 0:
        data_40[index] = [0]
violin_40 = plt.violinplot(data_40, positions=[x+0.45 for x in range(0, (len(scaffold_names) + 1) *2, 2)])
plt.boxplot(data_40, positions=[x+0.45 for x in range(0, (len(scaffold_names) + 1) *2, 2)])

# Set color for 40 dataset violins
for pc in violin_40['bodies']:
    pc.set_facecolor('red')
    pc.set_edgecolor('black')
    pc.set_alpha(0.7)

# Additional plot formatting
plt.xticks(range(0, (len(scaffold_names) + 1) *2, 2), labels, rotation=85)
plt.xlabel('Ring Name')
plt.ylabel('Msm Standardized Residual')
plt.title('Msm Standardized Residual by Ring Name - Only non-Fused Scaffolds')
plt.ylim(-3.5,2)
# Add custom legend
legend_elements = [
    Patch(facecolor='cyan', edgecolor='black', label='1200'),
    Patch(facecolor='orange', edgecolor='black', label='380'),
    Patch(facecolor='red', edgecolor='black', label='40')
]
plt.legend(handles=legend_elements)
plt.tight_layout()
plt.savefig('./figures/msm_std_resid_by_ring_non_fused.svg')
plt.clf()

# Set up font size
plt.rcParams['font.size'] = 15

# Prepare labels
labels = list(comprehensive_data['380']['scaffolds'].keys())
labels.append('All')

# First data set - 1200
data_1200 = []
for label, scaff_list in comprehensive_data['1200']['non_fused'].items():
    data_1200.append(list(compress(comprehensive_data['1200']['mtb_old_resid_std'], scaff_list)))
data_1200.append(pd.Series(comprehensive_data['1200']['mtb_old_resid_std']).dropna())
for index, l in enumerate(data_1200[:-1]):
    if len(l) == 0:
        data_1200[index] = [0]
violin_1200 = plt.violinplot(data_1200, positions=[x-0.45 for x in range(0, (len(scaffold_names) + 1) *2, 2)])
plt.boxplot(data_1200, positions=[x-0.45 for x in range(0, (len(scaffold_names) + 1) *2, 2)])

# Set color for 1200 dataset violins
for pc in violin_1200['bodies']:
    pc.set_facecolor('cyan')
    pc.set_edgecolor('black')
    pc.set_alpha(0.7)

# Second data set - 380
data_380 = []
for label, scaff_list in comprehensive_data['380']['non_fused'].items():
    data_380.append(list(compress(comprehensive_data['380']['mtb_old_resid_std'], scaff_list)))
data_380.append(pd.Series(comprehensive_data['380']['mtb_old_resid_std']).dropna())
for index, l in enumerate(data_380[:-1]):
    if len(l) == 0:
        data_380[index] = [0]
violin_380 = plt.violinplot(data_380, positions=[x for x in range(0, (len(scaffold_names) + 1) *2, 2)])
plt.boxplot(data_380, positions=[x for x in range(0, (len(scaffold_names) + 1) *2, 2)])

# Set color for 380 dataset violins
for pc in violin_380['bodies']:
    pc.set_facecolor('orange')
    pc.set_edgecolor('black')
    pc.set_alpha(0.7)

# Third data set - 40
data_40 = []
for label, scaff_list in comprehensive_data['40']['non_fused'].items():
    data_40.append(list(compress(comprehensive_data['40']['mtb_old_resid_std'], scaff_list)))
data_40.append(pd.Series(comprehensive_data['40']['mtb_old_resid_std']).dropna())
for index, l in enumerate(data_40[:-1]):
    if len(l) == 0:
        data_40[index] = [0]
violin_40 = plt.violinplot(data_40, positions=[x+0.45 for x in range(0, (len(scaffold_names) + 1) *2, 2)])
plt.boxplot(data_40, positions=[x+0.45 for x in range(0, (len(scaffold_names) + 1) *2, 2)])

# Set color for 40 dataset violins
for pc in violin_40['bodies']:
    pc.set_facecolor('red')
    pc.set_edgecolor('black')
    pc.set_alpha(0.7)

# Additional plot formatting
plt.xticks(range(0, (len(scaffold_names) + 1) *2, 2), labels, rotation=85)
plt.xlabel('Ring Name')
plt.ylabel('Mtb Standardized Residual')
plt.title('Mtb Standardized Residual by Ring Name - Only non-Fused Scaffolds')
plt.ylim(-3.5,2)
# Add custom legend
legend_elements = [
    Patch(facecolor='cyan', edgecolor='black', label='1200'),
    Patch(facecolor='orange', edgecolor='black', label='380'),
    Patch(facecolor='red', edgecolor='black', label='40')
]
plt.legend(handles=legend_elements)
plt.tight_layout()
plt.savefig('./figures/mtb_std_resid_by_ring_non_fused.svg')
plt.clf()

# Assuming comprehensive_data dictionary is available
keys_to_remove = ['Compound_#', 'MOL', 'scaffolds', 'fused', 'non_fused', 'props']

# Convert SMILES to canonical form and create new columns for canonical SMILES and dataset labels
df1 = pd.DataFrame(remove_keys(comprehensive_data['1200'], keys_to_remove))
df2 = pd.DataFrame(remove_keys(comprehensive_data['380'], keys_to_remove))
df3 = pd.DataFrame(remove_keys(comprehensive_data['40'], keys_to_remove))
df1['canonical_smiles'] = df1['Smiles'].apply(canonicalize_smiles)
df2['canonical_smiles'] = df2['Smiles'].apply(canonicalize_smiles)
df3['canonical_smiles'] = df3['Smiles'].apply(canonicalize_smiles)
df1['dataset'] = '1200'
df2['dataset'] = '380'
df3['dataset'] = '40'

# Drop original SMILES column if not needed
df1 = df1.drop(columns=['Smiles'])
df2 = df2.drop(columns=['Smiles'])
df3 = df3.drop(columns=['Smiles'])

# Concatenate datasets
combined_df = pd.concat([df1, df2, df3], ignore_index=True)

# Sort by dataset to prioritize smaller datasets
dataset_priority = {'1200': 1, '380': 2, '40': 3}
combined_df['dataset_priority'] = combined_df['dataset'].map(dataset_priority)
combined_df = combined_df.sort_values(by=['canonical_smiles', 'dataset_priority'], ascending=[True, False])

# Drop duplicates, keeping the last occurrence (highest priority)
result_df = combined_df.drop_duplicates(subset='canonical_smiles', keep='last').drop(columns='dataset_priority')

# Add molecule column and classify amine type
PandasTools.AddMoleculeColumnToFrame(result_df, 'canonical_smiles', 'molecule', includeFingerprints=True)
result_df['Amine_Type'] = result_df['molecule'].apply(classify_amine)

# Filter out rows where Amine_Type is None (non-amines)
df_filtered = result_df[result_df['Amine_Type'].notnull()]

# Define the order for amine types
amine_order = ['Primary Amine', 'Secondary Amine', 'Tertiary Amine']
df_filtered['Amine_Type'] = pd.Categorical(df_filtered['Amine_Type'], categories=amine_order, ordered=True)

# Calculate the number of molecules per amine type
amine_counts = df_filtered['Amine_Type'].value_counts()

# Plot violin plot for standardized residuals grouped by amine type
plt.figure(figsize=(10, 6))
ax = sns.violinplot(x='Amine_Type', y='mtb_old_resid_std', data=df_filtered, palette='muted', order=amine_order)

# Add molecule counts above each violin plot
for i, amine_type in enumerate(amine_order):
    count = amine_counts.get(amine_type, 0)
    ax.text(i, df_filtered['mtb_old_resid_std'].max() + 0.4, f'n = {count}', 
            ha='center', va='bottom', fontsize=12, fontweight='bold')

# Customize plot
plt.title('Standardized Residuals by Amine Type with Molecule Counts')
plt.ylabel('Standardized Residual')
plt.xlabel('Amine Type')
plt.tight_layout()
plt.savefig('./figures/mtb_std_resid_by_amine_type.svg')
plt.clf()
print('Saving outputs')
# Save the final DataFrame to CSV with a "Source_Library" column
result_df['Lipinski'] = [check_lipinski(x) for x in result_df.molecule]
result_df['eNTRy'] = [check_entry(x) for x in result_df.molecule]
result_df.to_csv('./processed_data/20241104_combined_dataset.csv', index=False)

#40 no ring
no_ring = {'smiles':[], 'mtb':[], 'msm':[]}
has_ring = {'smiles':[], 'mtb':[], 'msm':[]}
scaffolds = {scaffold_name:{'smiles':[], 'mtb':[], 'msm':[]} for scaffold_name in comprehensive_data['40']['scaffolds'].keys()}
greedy_scaffolds = {'greedy_'+scaffold_name:{'smiles':[], 'mtb':[], 'msm':[]} for scaffold_name in comprehensive_data['40']['scaffolds'].keys()}
fused_scaffolds = {'fused_'+scaffold_name:{'smiles':[], 'mtb':[], 'msm':[]} for scaffold_name in comprehensive_data['40']['scaffolds'].keys()}
for i, smile in enumerate(comprehensive_data['40']['Smiles']):
    if comprehensive_data['40']['has_ring'][i]:
        has_ring['smiles'].append(smile)
        has_ring['mtb'].append(comprehensive_data['40']['mtb_old_resid_std'][i])
        has_ring['msm'].append(comprehensive_data['40']['msm_old_resid_std'][i])
        for name in scaffolds.keys():
            if comprehensive_data['40']['scaffolds'][name][i]:
                scaffolds[name]['smiles'].append(smile)
                scaffolds[name]['mtb'].append(comprehensive_data['40']['mtb_old_resid_std'][i])
                scaffolds[name]['msm'].append(comprehensive_data['40']['msm_old_resid_std'][i])
        for name in scaffolds.keys():
            if comprehensive_data['40']['non_fused'][name][i]:
                greedy_scaffolds['greedy_'+name]['smiles'].append(smile)
                greedy_scaffolds['greedy_'+name]['mtb'].append(comprehensive_data['40']['mtb_old_resid_std'][i])
                greedy_scaffolds['greedy_'+name]['msm'].append(comprehensive_data['40']['msm_old_resid_std'][i])
        for name in scaffolds.keys():
            if comprehensive_data['40']['fused'][name][i]:
                fused_scaffolds['fused_'+name]['smiles'].append(smile)
                fused_scaffolds['fused_'+name]['mtb'].append(comprehensive_data['40']['mtb_old_resid_std'][i])
                fused_scaffolds['fused_'+name]['msm'].append(comprehensive_data['40']['msm_old_resid_std'][i])
    else:
        no_ring['smiles'].append(smile)
        no_ring['mtb'].append(comprehensive_data['40']['mtb_old_resid_std'][i])
        no_ring['msm'].append(comprehensive_data['40']['msm_old_resid_std'][i])
dfs = [pd.DataFrame(no_ring), pd.DataFrame(has_ring)]
for dict in scaffolds.values():
    dfs.append(pd.DataFrame(dict))
for dict in greedy_scaffolds.values():
    dfs.append(pd.DataFrame(dict))
for dict in fused_scaffolds.values():
    dfs.append(pd.DataFrame(dict))

workbook = load_workbook('./processed_data/20241104_40_scaffold.xlsx')
sheet_names = ['no_ring', 'has_ring']
for i in scaffolds.keys():
    sheet_names.append(i)
for i in greedy_scaffolds.keys():
    sheet_names.append(i)
for i in fused_scaffolds.keys():
    sheet_names.append(i)

workbook.save('./processed_data/20241104_40_scaffold.xlsx')

with pd.ExcelWriter('./processed_data/20241104_40_scaffold.xlsx', engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
    #writer.book = workbook
    for i, name in enumerate(sheet_names):
        dfs[i].to_excel(writer, sheet_name=name)

#380 Scaffolds
no_ring = {'smiles':[], 'mtb':[], 'msm':[]}
has_ring = {'smiles':[], 'mtb':[], 'msm':[]}
scaffolds = {scaffold_name:{'smiles':[], 'mtb':[], 'msm':[]} for scaffold_name in comprehensive_data['380']['scaffolds'].keys()}
greedy_scaffolds = {'greedy_'+scaffold_name:{'smiles':[], 'mtb':[], 'msm':[]} for scaffold_name in comprehensive_data['380']['scaffolds'].keys()}
fused_scaffolds = {'fused_'+scaffold_name:{'smiles':[], 'mtb':[], 'msm':[]} for scaffold_name in comprehensive_data['380']['scaffolds'].keys()}
for i, smile in enumerate(comprehensive_data['380']['Smiles']):
    if comprehensive_data['380']['has_ring'][i]:
        has_ring['smiles'].append(smile)
        has_ring['mtb'].append(comprehensive_data['380']['mtb_old_resid_std'][i])
        has_ring['msm'].append(comprehensive_data['380']['msm_old_resid_std'][i])
        for name in scaffolds.keys():
            if comprehensive_data['380']['scaffolds'][name][i]:
                scaffolds[name]['smiles'].append(smile)
                scaffolds[name]['mtb'].append(comprehensive_data['380']['mtb_old_resid_std'][i])
                scaffolds[name]['msm'].append(comprehensive_data['380']['msm_old_resid_std'][i])
        for name in scaffolds.keys():
            if comprehensive_data['380']['non_fused'][name][i]:
                greedy_scaffolds['greedy_'+name]['smiles'].append(smile)
                greedy_scaffolds['greedy_'+name]['mtb'].append(comprehensive_data['380']['mtb_old_resid_std'][i])
                greedy_scaffolds['greedy_'+name]['msm'].append(comprehensive_data['380']['msm_old_resid_std'][i])
        for name in scaffolds.keys():
            if comprehensive_data['380']['fused'][name][i]:
                fused_scaffolds['fused_'+name]['smiles'].append(smile)
                fused_scaffolds['fused_'+name]['mtb'].append(comprehensive_data['380']['mtb_old_resid_std'][i])
                fused_scaffolds['fused_'+name]['msm'].append(comprehensive_data['380']['msm_old_resid_std'][i])
    else:
        no_ring['smiles'].append(smile)
        no_ring['mtb'].append(comprehensive_data['380']['mtb_old_resid_std'][i])
        no_ring['msm'].append(comprehensive_data['380']['msm_old_resid_std'][i])
dfs = [pd.DataFrame(no_ring), pd.DataFrame(has_ring)]
for dict in scaffolds.values():
    dfs.append(pd.DataFrame(dict))
for dict in greedy_scaffolds.values():
    dfs.append(pd.DataFrame(dict))
for dict in fused_scaffolds.values():
    dfs.append(pd.DataFrame(dict))

workbook = load_workbook('./processed_data/20241104_380_scaffold.xlsx')
sheet_names = ['no_ring', 'has_ring']
for i in scaffolds.keys():
    sheet_names.append(i)
for i in greedy_scaffolds.keys():
    sheet_names.append(i)
for i in fused_scaffolds.keys():
    sheet_names.append(i)

workbook.save('./processed_data/20241104_380_scaffold.xlsx')

with pd.ExcelWriter('./processed_data/20241104_380_scaffold.xlsx', engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
    #writer.book = workbook
    for i, name in enumerate(sheet_names):
        dfs[i].to_excel(writer, sheet_name=name)

#1200 Scaffolds
no_ring = {'smiles':[], 'mtb':[], 'msm':[]}
has_ring = {'smiles':[], 'mtb':[], 'msm':[]}
scaffolds = {scaffold_name:{'smiles':[], 'mtb':[], 'msm':[]} for scaffold_name in comprehensive_data['1200']['scaffolds'].keys()}
greedy_scaffolds = {'greedy_'+scaffold_name:{'smiles':[], 'mtb':[], 'msm':[]} for scaffold_name in comprehensive_data['1200']['scaffolds'].keys()}
fused_scaffolds = {'fused_'+scaffold_name:{'smiles':[], 'mtb':[], 'msm':[]} for scaffold_name in comprehensive_data['1200']['scaffolds'].keys()}
for i, smile in enumerate(comprehensive_data['1200']['Smiles']):
    if comprehensive_data['1200']['has_ring'][i]:
        has_ring['smiles'].append(smile)
        has_ring['mtb'].append(comprehensive_data['1200']['mtb_old_resid_std'][i])
        has_ring['msm'].append(comprehensive_data['1200']['msm_old_resid_std'][i])
        for name in scaffolds.keys():
            if comprehensive_data['1200']['scaffolds'][name][i]:
                scaffolds[name]['smiles'].append(smile)
                scaffolds[name]['mtb'].append(comprehensive_data['1200']['mtb_old_resid_std'][i])
                scaffolds[name]['msm'].append(comprehensive_data['1200']['msm_old_resid_std'][i])
        for name in scaffolds.keys():
            if comprehensive_data['1200']['non_fused'][name][i]:
                greedy_scaffolds['greedy_'+name]['smiles'].append(smile)
                greedy_scaffolds['greedy_'+name]['mtb'].append(comprehensive_data['1200']['mtb_old_resid_std'][i])
                greedy_scaffolds['greedy_'+name]['msm'].append(comprehensive_data['1200']['msm_old_resid_std'][i])
        for name in scaffolds.keys():
            if comprehensive_data['1200']['fused'][name][i]:
                fused_scaffolds['fused_'+name]['smiles'].append(smile)
                fused_scaffolds['fused_'+name]['mtb'].append(comprehensive_data['1200']['mtb_old_resid_std'][i])
                fused_scaffolds['fused_'+name]['msm'].append(comprehensive_data['1200']['msm_old_resid_std'][i])
    else:
        no_ring['smiles'].append(smile)
        no_ring['mtb'].append(comprehensive_data['1200']['mtb_old_resid_std'][i])
        no_ring['msm'].append(comprehensive_data['1200']['msm_old_resid_std'][i])
dfs = [pd.DataFrame(no_ring), pd.DataFrame(has_ring)]
for dict in scaffolds.values():
    dfs.append(pd.DataFrame(dict))
for dict in greedy_scaffolds.values():
    dfs.append(pd.DataFrame(dict))
for dict in fused_scaffolds.values():
    dfs.append(pd.DataFrame(dict))

workbook = load_workbook('./processed_data/20241104_1200_scaffold.xlsx')
sheet_names = ['no_ring', 'has_ring']
for i in scaffolds.keys():
    sheet_names.append(i)
for i in greedy_scaffolds.keys():
    sheet_names.append(i)
for i in fused_scaffolds.keys():
    sheet_names.append(i)

workbook.save('./processed_data/20241104_1200_scaffold.xlsx')

with pd.ExcelWriter('./processed_data/20241104_1200_scaffold.xlsx', engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
    #writer.book = workbook
    for i, name in enumerate(sheet_names):
        dfs[i].to_excel(writer, sheet_name=name)