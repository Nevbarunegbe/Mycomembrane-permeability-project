import pandas as pd
import statsmodels.api as sm

#RDKit
from rdkit import Chem
from rdkit.Chem import AllChem
from rdkit.Chem import Descriptors
from rdkit.Chem import rdMolDescriptors
from rdkit.Chem import Crippen
#Functions
def are_molecules_identical(mol1, mol2):
    return Chem.MolToSmiles(mol1, isomericSmiles=True) == Chem.MolToSmiles(mol2, isomericSmiles=True)

def calc_residuals(comprehensive_data, library):
    mtb = pd.DataFrame({'logReact':comprehensive_data[library]['logReact'], 'mtb': comprehensive_data[library]['mtb']}).dropna()
    msm = pd.DataFrame({'logReact':comprehensive_data[library]['logReact'], 'msm': comprehensive_data[library]['msm']}).dropna()
    X = mtb['logReact']
    y = mtb['mtb']
    model = sm.OLS(y, X).fit()
    new_data = {'logReact':comprehensive_data[library]['logReact'], 'mtb': comprehensive_data[library]['mtb']}
    print(len(new_data['logReact']))
    y_pred = model.predict(new_data['logReact'])
    new_data['Predicted_Y'] = y_pred
    # Calculate residuals - 380 mtb
    comprehensive_data[library]['mtb_old_resid'] = new_data['mtb'] - new_data['Predicted_Y']
    print(len(comprehensive_data[library]['mtb_old_resid']))
    X = msm['logReact']
    y = msm['msm']
    model = sm.OLS(y, X).fit()
    new_data = pd.DataFrame({'logReact':comprehensive_data[library]['logReact'], 'msm': comprehensive_data[library]['msm']})
    y_pred = model.predict(new_data['logReact'])
    new_data['Predicted_Y'] = y_pred
    # Calculate residuals - 380 msm
    comprehensive_data[library]['msm_old_resid'] = new_data['msm'] - new_data['Predicted_Y']

def calculate_logp(mol):
    if mol:  # Ensure the molecule is valid
        return Crippen.MolLogP(mol)
    else:
        return None  # Return None if the SMILES is invalid

def calculate_tpsa(mol):
    if mol:  # Ensure the molecule is valid
        return rdMolDescriptors.CalcTPSA(mol)
    else:
        return None  # Return None if the SMILES is invalid

def canonicalize_smiles(smiles):
    """Convert SMILES to its canonical form."""
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        return Chem.MolToSmiles(mol, canonical=True)
    return None

def check_entry(mol):
    rot_bonds = Descriptors.NumRotatableBonds(mol)
    molh = Chem.AddHs(mol)
    # Generate 3D coordinates
    AllChem.EmbedMolecule(molh, AllChem.ETKDG())  # Use ETKDG for good conformer generation
    AllChem.UFFOptimizeMolecule(molh)  # Optionally, optimize the structure with UFF

    # Calculate Radius of Gyration
    radius_of_gyration = rdMolDescriptors.CalcRadiusOfGyration(molh)

    # Calculate Molecular Volume
    mol_volume = rdMolDescriptors.CalcExactMolWt(molh)  # Placeholder for molecular weight
    
    # Optionally, use rdkit.Chem.rdFreeSASA to estimate solvent-accessible surface area
    # For simplicity, globularity approximation as ratio of radius_of_gyration to volume
    globularity = radius_of_gyration / mol_volume
    entry_violations = 0
    if not mol.HasSubstructMatch(Chem.MolFromSmarts('[NX3;H2]')):
        entry_violations += 1
    if globularity > 0.25:
        entry_violations += 1
    if rot_bonds > 5:
        entry_violations += 1
    return entry_violations == 0

def check_lipinski(mol):
    hbd = Descriptors.NumHDonors(mol)  # Number of H-bond donors
    hba = Descriptors.NumHAcceptors(mol)  # Number of H-bond acceptors
    mw = Descriptors.MolWt(mol)  # Molecular weight
    logp = Descriptors.MolLogP(mol)  # LogP (octanol-water partition coefficient)
    
    lipinski_violations = 0
    if hbd > 5:
        lipinski_violations += 1
    if hba > 10:
        lipinski_violations += 1
    if mw > 500:
        lipinski_violations += 1
    if logp > 5:
        lipinski_violations += 1
    
    return lipinski_violations == 0  # Returns True if it passes Lipinski's rules

def check_veber(mol):
    rot_bonds = Descriptors.NumRotatableBonds(mol)
    tpsa = rdMolDescriptors.CalcTPSA(mol)  # Topological Polar Surface Area (TPSA)
    
    veber_violations = 0
    if rot_bonds > 10:
        veber_violations += 1
    if tpsa > 140:
        veber_violations += 1
    return veber_violations == 0  # Returns True if it passes Veber's rules

def classify_amine(mol):
    # Define SMARTS patterns for primary, secondary, and tertiary amines
    primary_amine_smarts = '[NX3;H2]'
    secondary_amine_smarts = '[NX3;H1]'
    tertiary_amine_smarts = '[NX3;H0]'
    if mol.HasSubstructMatch(Chem.MolFromSmarts(primary_amine_smarts)):
        return 'Primary Amine'
    elif mol.HasSubstructMatch(Chem.MolFromSmarts(secondary_amine_smarts)):
        return 'Secondary Amine'
    elif mol.HasSubstructMatch(Chem.MolFromSmarts(tertiary_amine_smarts)):
        return 'Tertiary Amine'
    else:
        return None

def count_heteroatoms_in_rings(mol):  # Create molecule object
    if mol is not None:
        ring_info = mol.GetRingInfo()  # Get ring information
        if len(ring_info.AtomRings()[:1]) == 1:

            heteroatom_count = 0
            for ring in ring_info.AtomRings()[:1]:  # Iterate through rings
                for atom_idx in ring:  # Iterate through atoms in the ring
                    atom = mol.GetAtomWithIdx(atom_idx)
                    if atom.GetAtomicNum() not in [6, 1]:  # Count if atom is not C (6) or H (1)
                        heteroatom_count += 1
            return heteroatom_count
        return -1
    return None  # Return None for invalid SMILES

def count_rings(mol):
    return mol.GetRingInfo().NumRings()

def is_scaffold_fused_in_molecule(molecule, scaffold):
    # Find all substructure matches
    matches = molecule.GetSubstructMatches(scaffold)
    if not matches:
        return False
    # Find ring systems
    ssr = [set(x) for x in Chem.GetSymmSSSR(molecule)]
    for match in matches:
        scaffold_atoms = set(match)
        scaffold_rings = [ring for ring in ssr if scaffold_atoms.issubset(ring)]
        if not scaffold_rings:
            continue
        for ring in scaffold_rings:
            fused = any(len(ring.intersection(other_ring)) > 0 for other_ring in ssr if ring != other_ring)
            if fused:
                return 'fused'
    return 'non_fused'

# Function to remove specific keys from a dictionary
def remove_keys(original_dict, keys_to_remove):
    return {k: v for k, v in original_dict.items() if k not in keys_to_remove}