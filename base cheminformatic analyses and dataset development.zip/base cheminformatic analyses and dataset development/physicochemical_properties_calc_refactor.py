from rdkit import Chem, DataStructs
from rdkit.Chem import AllChem, Draw, rdMolDescriptors, QED, FindMolChiralCenters
from rdkit.Chem.Scaffolds.MurckoScaffold import GetScaffoldForMol
from rdkit.Chem import rdDistGeom, AllChem, rdMolAlign, rdFreeSASA
from rdkit.Chem.rdmolops import GetFormalCharge
from itertools import combinations
import sys
import numpy as np
import pandas as pd
import argparse
from tqdm import tqdm
from multiprocessing import Pool
#from collections import defaultdict

def fused_ring_count(m):
    """
    Count the number of rings that are fused together.
    :param m: RDKit molecule object
    :return: number of fused rings.
    """
    q = m.GetRingInfo()
    rings = [set(r) for r in q.AtomRings()]
    go_next = True
    while go_next:
        go_next = False
        for i, j in combinations(range(len(rings)), 2):
            if rings[i] & rings[j]:
                q = rings[i] | rings[j]
                del rings[j], rings[i]
                rings.append(q)
                go_next = True
                break
    return len(rings)


def count_hbd_hba_atoms(m):
    """
    Count the number of hydrogen bond donor and acceptor atoms.
    :param m: RDKit molecule object
    :return: non-reduntant number of hydrogen bond donor and acceptor atoms.
    """
    HDonorSmarts = Chem.MolFromSmarts('[$([N;!H0;v3]),$([N;!H0;+1;v4]),$([O,S;H1;+0]),$([n;H1;+0])]')
    HAcceptorSmarts = Chem.MolFromSmarts('[$([O,S;H1;v2]-[!$(*=[O,N,P,S])]),' +
                                         '$([O,S;H0;v2]),$([O,S;-]),$([N;v3;!$(N-*=!@[O,N,P,S])]),' +
                                         '$([nH0,o,s;+0])]')
    HDonor = m.GetSubstructMatches(HDonorSmarts)
    HAcceptor = m.GetSubstructMatches(HAcceptorSmarts)
    return len(set(HDonor + HAcceptor))


def confgen(smile,  prunermsthresh, numconf, add_ref):
    """
    Generate conformers for a given molecule.
    :param smile: SMILES string for a molecule.
    :param prunermsthresh: pruning RMS threshold.
    :param numconf: number of conformers to generate.
    :param add_ref: whether to add a reference conformer.
    :return: RDKit molecule object with conformers.
    """
    print('confgen')
    print('mol')
    mol = Chem.AddHs(Chem.MolFromSmiles(smile), addCoords=True)
    print('refmol')
    refmol = Chem.AddHs(Chem.Mol(mol))
    print('param')
    param = rdDistGeom.ETKDGv2()
    print('pruneRmsThresh')
    param.pruneRmsThresh = prunermsthresh
    print('cids')
    cids = rdDistGeom.EmbedMultipleConfs(mol, numconf, param)
    print('mp')
    mp = AllChem.MMFFGetMoleculeProperties(mol, mmffVariant='MMFF94s')
    print('MMFFOptimizeMoleculeConfs')
    AllChem.MMFFOptimizeMoleculeConfs(mol, numThreads=4, mmffVariant='MMFF94s')
    # w = Chem.SDWriter(output)
    print(add_ref)
    if add_ref:
        refmol.SetProp('CID', '-1')
        refmol.SetProp('Energy', '')
        w.write(refmol)
    res = []
    print(cids)
    for cid in cids:
        print(cid)
        print('ff')
        ff = AllChem.MMFFGetMoleculeForceField(mol, mp, confId=cid)
        print('e')
        e = ff.CalcEnergy()
        print('update res')
        res.append((cid, e))
    print('sort refs')
    sorted_res = sorted(res, key=lambda x: x[1])
    print('alignmolconformers')
    rdMolAlign.AlignMolConformers(mol)
    for cid, e in sorted_res:
        mol.SetProp('CID', str(cid))
        mol.SetProp('Energy', str(e))
        # w.write(mol, confId=cid)
    # w.close()
    print('return')
    return mol

def calc_globularity_pbf(mol):
    """
    Calculate globularity and PBF for a given molecule.
    :param mol: RDKit molecule object.
    :return: globularity and PBF.
    """
    glob_ls = []
    pbf_ls = []
    for i in range(len(mol.GetConformers())):
        radii1 = rdFreeSASA.classifyAtoms(mol)
        sasa = rdFreeSASA.CalcSASA(mol, radii1, confIdx=i)
        molv = AllChem.ComputeMolVolume(mol, confId=1)
        globularity = ((molv * 3 / (4 * np.pi)) ** (2 / 3)) * 4 * np.pi / sasa
        pbf = rdMolDescriptors.CalcPBF(mol)
        glob_ls.append(globularity)
        pbf_ls.append(pbf)
    return np.mean(np.asarray(glob_ls)), np.mean(np.asarray(pbf_ls))


def calc(inp_smi):
    """
    Chief function for calculating molecular descriptors.
    :param inp_smi: SMILES string for a molecule.
    :return: pre-calculated molecular descriptors.
    """
    m = Chem.MolFromSmiles(inp_smi)
    if m is not None:
        try:
            print('calculating properties')
            m = confgen(inp_smi, 0.1, 5, False)
            print('hba')
            hba = rdMolDescriptors.CalcNumHBA(m)
            print('hbd')
            hbd = rdMolDescriptors.CalcNumHBD(m)
            print('nrings')
            nrings = rdMolDescriptors.CalcNumRings(m)
            print('rtb')
            rtb = rdMolDescriptors.CalcNumRotatableBonds(m)
            print('glob, pbf')
            glob, pbf = calc_globularity_pbf(m)
            print('psa')
            psa = rdMolDescriptors.CalcTPSA(m)
            print('logP, mr')
            logp, mr = rdMolDescriptors.CalcCrippenDescriptors(m)
            print('mw')
            mw = rdMolDescriptors._CalcMolWt(m)
            print('csp3')
            csp3 = rdMolDescriptors.CalcFractionCSP3(m)
            print('hac')
            hac = m.GetNumHeavyAtoms()
            print('fmf')
            if hac == 0:
                fmf = 0
            else:
                fmf = GetScaffoldForMol(m).GetNumHeavyAtoms() / hac
            print('QED')
            qed = QED.qed(m)
            print('nrings_fused')
            nrings_fused = fused_ring_count(m)
            print('n_unique_hba_hbd_atoms')
            n_unique_hba_hbd_atoms = count_hbd_hba_atoms(m)
            print('max_ring_size')
            max_ring_size = len(max(m.GetRingInfo().AtomRings(), key=len, default=()))
            print('n_chiral_centers')
            n_chiral_centers = len(FindMolChiralCenters(m, includeUnassigned=True))
            print('fcsp3')
            fcsp3_bm = rdMolDescriptors.CalcFractionCSP3(GetScaffoldForMol(m))
            print('n_amide_bond')
            n_amide_bond = rdMolDescriptors.CalcNumAmideBonds(m)
            print('f_charge')
            f_charge = GetFormalCharge(m)
            print('abs_charge')
            abs_charge = abs(f_charge)
            return hba, hbd, hba + hbd, nrings, rtb, n_amide_bond, glob, pbf, round(psa, 2), round(logp, 2), \
                    round(mr, 2), round(mw, 2), round(csp3, 3), round(fmf, 3), round(qed, 3), hac, nrings_fused,\
                    n_unique_hba_hbd_atoms, max_ring_size, n_chiral_centers, round(fcsp3_bm, 3), \
                    round(f_charge, 3), round(abs_charge, 3)
        except:
            sys.stderr.write(f'molecule {inp_smi} was omitted due to an error in calculation of some descriptors\n')
            return None
    else:
        sys.stderr.write('smiles %s cannot be parsed ' % inp_smi)
        return None
def calculate_properties(smile, out_path, df, i):
    with open(out_path, "a") as f:

        res = calc(smile)
        try:
            f.write(','.join(map(str, df.iloc[i,:].to_list())) +',' + ','.join(map(str, res)) + '\n')
            print('mol #' + str(i))
        except:
            print("Nonetype")
        f.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser('Calculate protein RMSD')
    parser.add_argument('--datafile', type=str,
                        help='input datafile, 1st column numerical, 2nd colum smiles')
    parser.add_argument('--out_file', type=str,
                        help='outout physicochemical prop file')
    parser.add_argument('--smi_col', type=str, default='smiles',
                        help='column name of smiles (default: smiles)')
    args = parser.parse_args()
    data_path = args.datafile
    out_path = args.out_file
    smi_col = args.smi_col

    # Get SMILES and target values
    df = pd.read_csv(data_path, header=0)
    smiles = df[smi_col].tolist()
    property_ls = ['HBA', 'HBD', 'HBA+HBD', 'NumRings', 'RTB', 'NumAmideBonds',
                    'Globularity', 'PBF', 'TPSA', 'logP', 'MR', 'MW', 'Csp3',
                    'fmf', 'QED', 'HAC', 'NumRingsFused', 'unique_HBAD', 'max_ring_size',
                    'n_chiral_centers', 'fcsp3_bm', 'formal_charge', 'abs_charge']
    df_cols = df.columns.values.tolist()
    merge_cols = df_cols + property_ls
    with open(out_path, "w") as f:
        f.write(','.join(merge_cols) + '\n')
    num_processes = 8

# Create a pool of worker processes
    pool = Pool(processes=num_processes)

# Map the calculation function to the list of smiles
    results = pool.starmap(calculate_properties, [(smile, out_path, df, i) for i, smile in enumerate(smiles)])
# Close the pool to release resources
    pool.close()
    pool.join()
        

    ## This section used a lot of memory therefore shelved
    ## Calculate properties
    #property_dict = defaultdict(list)
    ## for smi in smiles:
    #for n in tqdm(range(len(smiles))):
    #    smi = smiles[n]
    #    res = calc(smi)
    #    if res is None:
    #        continue
    #    for i, prop in enumerate(property_ls):
    #        property_dict[prop].append(res[i])
    ## Update dataframe
    #for prop in property_ls:
    #    df[prop] = property_dict[prop]
    ## Write output file
    #df.to_csv(out_path, index=False)
    exit()
